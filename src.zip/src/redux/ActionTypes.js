export const ActionsTypes = {
    USER: "USER"
}