import { combineReducers } from "redux";
import {UserHolder} from './Reducer/User'

const reducers = combineReducers({
  UserHolder
});

export default reducers;